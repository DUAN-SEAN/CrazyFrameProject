﻿using System;
namespace CrazyEngine
{


    internal interface ITickable
    {
        void Tick();

    }
}