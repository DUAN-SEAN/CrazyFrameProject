﻿using System;
using System.Collections.Generic;

[Serializable]
public class Spaceship : Body
{

}
