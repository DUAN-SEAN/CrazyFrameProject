﻿using System;
using CrazyEngine;

namespace CrazyEngine
{

    [Serializable]
    public class Spaceship : Body
    {
        //TODO 特化飞船类型
    }
}