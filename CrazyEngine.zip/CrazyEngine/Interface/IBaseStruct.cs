﻿using System;
public interface IBaseStruct
{
    Vector2 Center { set; get; }
}
