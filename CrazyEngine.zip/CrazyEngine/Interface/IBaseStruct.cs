﻿using System;

namespace CrazyEngine
{
    public interface IBaseStruct
    {
        Vector2 Center { set; get; }


    }
}