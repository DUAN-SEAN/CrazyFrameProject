﻿
public interface ITickable
{
    void Tick();
}
